import streamlit as st
import pandas as pd
import numpy as np
import sqlite3
import hashlib
import os
from tensorflow.keras.models import load_model
import matplotlib.pyplot as plt
import yfinance as yf
from datetime import datetime
from sklearn.preprocessing import MinMaxScaler

# Database setup
def create_db():
    conn = sqlite3.connect("users.db")
    c = conn.cursor()
    c.execute("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE,
            password TEXT
        )
    """)
    conn.commit()
    conn.close()

def hash_password(password):
    return hashlib.sha256(password.encode()).hexdigest()

def register_user(username, password):
    conn = sqlite3.connect("users.db")
    c = conn.cursor()
    try:
        c.execute("INSERT INTO users (username, password) VALUES (?, ?)", (username, hash_password(password)))
        conn.commit()
        st.success("✅ Registration successful! Please log in.")
    except sqlite3.IntegrityError:
        st.error("❌ Username already exists. Choose a different one.")
    conn.close()

def authenticate_user(username, password):
    conn = sqlite3.connect("users.db")
    c = conn.cursor()
    c.execute("SELECT password FROM users WHERE username = ?", (username,))
    stored_password = c.fetchone()
    conn.close()
    if stored_password and stored_password[0] == hash_password(password):
        return True
    return False

# Initialize database
create_db()

# Initialize session state for authentication
if "authenticated" not in st.session_state:
    st.session_state.authenticated = False

st.title("📈 STOCK PRICE PREDICTOR 🚀")

# If not authenticated, show login/register menu
if not st.session_state.authenticated:
    menu = st.sidebar.selectbox("Menu", ["Login", "Register"])
    
    if menu == "Register":
        st.subheader("📝 Create a New Account")
        new_user = st.text_input("👤 Username")
        new_pass = st.text_input("🔒 Password", type="password")
        if st.button("Register"):
            register_user(new_user, new_pass)

    elif menu == "Login":
        st.subheader("🔐 Login to Your Account")
        username = st.text_input("👤 Username")
        password = st.text_input("🔒 Password", type="password")
        if st.button("Login"):
            if authenticate_user(username, password):
                st.session_state.authenticated = True
                st.success("✅ Login successful!")
                st.rerun()  # Refresh the app after login
            else:
                st.error("❌ Incorrect username or password.")
    
    st.stop()  # Stop execution if not logged in

# **Show Logout Button in Sidebar**
with st.sidebar:
    if st.button("🚪 Logout"):
        st.session_state.authenticated = False
        st.rerun()

# If authenticated, show only stock predictor UI
st.sidebar.subheader("📊 Stock Selection")
stock = st.sidebar.text_input("🔎 Enter the Stock Symbol:", "GOOG")

# Load Model
model_path = "k22_price_model.h5"
if not os.path.exists(model_path):
    st.error("❌ Model file not found! Please check the path.")
    st.stop()

try:
    model = load_model(model_path)
except Exception as e:
    st.error(f"⚠️ Error loading model: {e}")
    st.stop()

# Fetch stock data
def fetch_stock_data(stock_symbol):
    end = datetime.now()
    start = datetime(end.year - 20, end.month, end.day)
    data = yf.download(stock_symbol, start, end)
    if data.empty:
        st.error("⚠️ No data found for the entered stock symbol. Please check again.")
        st.stop()
    return data

google_data = fetch_stock_data(stock)

# Display Stock Data
st.subheader("📊 Stock Data Preview 📄")
st.dataframe(google_data.tail())

# Function to plot graphs
def plot_graph(title, full_data, ma_data=None, extra_ma_data=None):
    fig, ax = plt.subplots(figsize=(15, 6))
    ax.plot(full_data.index, full_data.Close, label='📉 Original Close Price', color='blue')
    if ma_data is not None:
        ax.plot(full_data.index, ma_data, label='📊 Moving Average', color='orange')
    if extra_ma_data is not None:
        ax.plot(full_data.index, extra_ma_data, label='📈 Additional MA', color='green')
    ax.set_title(title)
    ax.legend()
    st.pyplot(fig)

# Moving Averages & Plots
ma_periods = [250, 200, 100]
for period in ma_periods:
    google_data[f'MA_{period}'] = google_data['Close'].rolling(period).mean()
    plot_graph(f'📈 Close Price vs {period}-Day Moving Average', google_data, google_data[f'MA_{period}'])

# Comparing 100-day & 250-day MA
plot_graph("📊 100-Day vs 250-Day Moving Averages", google_data, google_data['MA_100'], google_data['MA_250'])

# Data Preprocessing for Prediction
split_index = int(len(google_data) * 0.7)
x_test = google_data[['Close']].iloc[split_index:]

scaler = MinMaxScaler(feature_range=(0, 1))
scaled_data = scaler.fit_transform(x_test)

x_data, y_data = [], []
for i in range(100, len(scaled_data)):
    x_data.append(scaled_data[i - 100:i])
    y_data.append(scaled_data[i])

x_data, y_data = np.array(x_data), np.array(y_data)

# Predict
try:
    predictions = model.predict(x_data)
    inv_pre = scaler.inverse_transform(predictions)
    inv_y_test = scaler.inverse_transform(y_data)
except Exception as e:
    st.error(f"⚠️ Error during prediction: {e}")
    st.stop()

# Display Predictions
plot_data = pd.DataFrame({'🟢 Original': inv_y_test.flatten(), '🔴 Predicted': inv_pre.flatten()},
                         index=google_data.index[split_index + 100:])
st.subheader("📊 Original vs Predicted Stock Prices 📈")
st.dataframe(plot_data.tail())

# Plot Predictions
fig, ax = plt.subplots(figsize=(15, 6))
ax.plot(plot_data.index, plot_data['🟢 Original'], label="🟢 Original Prices", color='blue')
ax.plot(plot_data.index, plot_data['🔴 Predicted'], label="🔴 Predicted Prices", color='red')
ax.legend()
st.pyplot(fig)
